Please contact : frederic.scherma@clermont.inra.fr or nicolas.guilhot@clermont.inra.fr

Description: Inra GDEC Toolkit
        =================
        
        Set of very usefull components used in many of our projects.
        
Keywords: inra gdec web toolkit development
Platform: UNKNOWN
Classifier: Development Status :: 3 - Production
Classifier: Intended Audience :: Developers
Classifier: Topic :: Software Development :: Build Tools
Classifier: License :: Proprietary License
Classifier: Programming Language :: Python :: 3.4
