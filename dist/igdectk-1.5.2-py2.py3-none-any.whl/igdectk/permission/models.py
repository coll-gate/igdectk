# -*- coding: utf-8; -*-
#
# Copyright (c) 2015 INRA UMR1095 GDEC

"""
Permission backend extension models
"""

import datetime

from mongoengine import Document
from mongoengine import fields

