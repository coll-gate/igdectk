# -*- coding: utf-8; -*-
#
# Copyright (c) 2015 INRA UMR1095 GDEC

"""
Bootstrap sub-module/Django-application settings
"""

APP_VERBOSE_NAME = "igdectk.bootstrap"

APP_SETTINGS_MODEL = None

APP_VERSION = (1, 0, 1)
