# -*- coding: utf-8; -*-
#
# Copyright (c) 2015 INRA UMR1095 GDEC

"""
Permission backend extension models
"""

import datetime

from django_mongoengine import Document
from django_mongoengine import fields

