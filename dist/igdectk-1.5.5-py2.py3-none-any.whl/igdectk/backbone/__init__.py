# -*- coding: utf-8; -*-
#
# Copyright (c) 2016 INRA UMR1095 GDEC

"""
Backbone Django integration sub-package init.
"""

# Application Config for startup and more...
default_app_config = __name__ + '.apps.IgdecTkBackbone'

PACKAGER = 'backbone'
