# -*- coding: utf-8; -*-
#
# @file __init__.py
# @brief Auth sub-package init.
# @author Frédéric SCHERMA (INRA UMR1095)
# @date 2015-04-13
# @copyright Copyright (c) 2015 INRA
# @license MIT (see LICENSE file)
# @details
