# -*- coding: utf-8; -*-
#
# @file __init__.py
# @brief Packager application initialization helper.
# @author Frédéric SCHERMA (INRA UMR1095)
# @date 2014-06-03
# @copyright Copyright (c) 2014 INRA
# @license MIT (see LICENSE file)
# @details
