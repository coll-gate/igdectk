# -*- coding: utf-8; -*-
#
# Copyright (c) 2014 INRA UMR1095 GDEC

"""
Contains packager module exceptions
"""


class UnsupportedPackagerConfiguration(Exception):
    pass
